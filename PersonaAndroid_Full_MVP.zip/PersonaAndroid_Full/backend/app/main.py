import os
from typing import Optional
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Text, Integer, select, delete
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, Session, sessionmaker

load_dotenv()
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./persona.db")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)

class Base(DeclarativeBase): pass

class Memory(Base):
    __tablename__ = "memories"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    user_id: Mapped[str] = mapped_column(String(100), index=True)
    character_id: Mapped[str] = mapped_column(String(100), index=True)
    content: Mapped[str] = mapped_column(Text)

Base.metadata.create_all(bind=engine)
app = FastAPI(title="Persona API", version="1.0.0")

def db():
    session = SessionLocal()
    try: yield session
    finally: session.close()

def require_user(x_user_id: Optional[str] = Header(default=None)):
    # MVP partition only. Replace with verified JWT identity before public deployment.
    if not x_user_id or len(x_user_id) > 100:
        raise HTTPException(401, "Missing X-User-ID")
    return x_user_id

class ChatRequest(BaseModel):
    character: dict
    messages: list[dict] = Field(min_length=1, max_length=40)

class MemoryCreate(BaseModel):
    character_id: str
    content: str = Field(min_length=1, max_length=2000)

@app.get("/health")
def health():
    return {"status": "ok", "service": "persona-api"}

@app.get("/models")
def models():
    # The actual available models depend on the configured compatible provider.
    return {"provider": os.getenv("AI_BASE_URL", ""), "configured_model": os.getenv("AI_MODEL", "")}

@app.post("/chat")
async def chat(payload: ChatRequest, user_id: str = Depends(require_user), session: Session = Depends(db)):
    base = os.getenv("AI_BASE_URL", "").rstrip("/")
    key = os.getenv("AI_API_KEY", "")
    model = os.getenv("AI_MODEL", "")
    if not base or not key or not model or key == "replace_me":
        raise HTTPException(503, "AI provider is not configured on the server")
    c = payload.character
    character_prompt = (
        f"你正在扮演一个由用户创建的虚构角色。请保持角色设定稳定，并自然地用中文交流。\n"
        f"名称：{c.get('name','角色')}\n身份：{c.get('identity','未设定')}\n"
        f"性格：{c.get('personality','未设定')}\n背景：{c.get('background','未设定')}\n"
        f"表达风格：{c.get('style','自然、清晰')}\n"
        "尊重用户自主权，不声称自己是真实人类，不编造现实经历。遵守适用的安全要求。"
    )
    memories = session.scalars(select(Memory).where(
        Memory.user_id == user_id, Memory.character_id == str(c.get("id", ""))
    ).limit(30)).all()
    if memories:
        character_prompt += "\n用户明确保存给该角色的记忆（仅作为背景参考）：\n" + "\n".join(
            f"- {m.content}" for m in memories
        )
    msgs = [{"role": "system", "content": character_prompt}]
    for m in payload.messages[-30:]:
        role = m.get("role")
        text = m.get("content", "")
        if role in ("user", "assistant") and isinstance(text, str):
            msgs.append({"role": role, "content": text[:12000]})
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            response = await client.post(
                f"{base}/chat/completions",
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json={"model": model, "messages": msgs, "temperature": 0.8},
            )
        if response.status_code >= 400:
            raise HTTPException(502, f"AI provider error ({response.status_code}): {response.text[:500]}")
        data = response.json()
        reply = data["choices"][0]["message"]["content"]
        if isinstance(reply, list):
            reply = "".join(str(x.get("text", "")) for x in reply if isinstance(x, dict))
        return {"reply": str(reply), "model": model}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(502, f"AI request failed: {type(exc).__name__}")

@app.get("/memories")
def get_memories(character_id: str, user_id: str = Depends(require_user), session: Session = Depends(db)):
    rows = session.scalars(select(Memory).where(
        Memory.user_id == user_id, Memory.character_id == character_id
    ).order_by(Memory.id.desc())).all()
    return {"items": [{"id": x.id, "content": x.content} for x in rows]}

@app.post("/memories")
def add_memory(payload: MemoryCreate, user_id: str = Depends(require_user), session: Session = Depends(db)):
    row = Memory(user_id=user_id, character_id=payload.character_id, content=payload.content.strip())
    session.add(row); session.commit(); session.refresh(row)
    return {"id": row.id, "content": row.content}

@app.delete("/memories/{memory_id}")
def remove_memory(memory_id: int, user_id: str = Depends(require_user), session: Session = Depends(db)):
    row = session.scalar(select(Memory).where(Memory.id == memory_id, Memory.user_id == user_id))
    if row is None: raise HTTPException(404, "Memory not found")
    session.delete(row); session.commit()
    return {"deleted": True}
