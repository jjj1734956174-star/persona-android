# 只有 Android 手机时如何继续

## 最简单的路线
1. 将整个 ZIP 保存到手机。
2. 找一个支持 GitHub 导入与 Flutter Android 构建的云端开发/构建环境。
3. 将 ZIP 解压并导入，Flutter 项目目录是 `app/`。
4. 在云端构建环境运行 `flutter pub get`。
5. 配置 `API_BASE_URL`，再运行：
   `flutter build apk --release --dart-define=API_BASE_URL=https://你的后端域名`
6. 下载生成的 APK 到手机安装。Android 可能要求允许从该来源安装应用。

## 后端
后端目录是 `backend/`。部署到支持 Python/FastAPI 或 Docker 的服务器。
将 `.env.example` 复制为 `.env`，填写模型服务商给出的兼容 API 地址、API Key 和模型 ID。
不同服务商的 API 兼容程度可能不同，需要按服务商文档核对。

## 语音
客户端使用 Android 设备可用的语音识别服务和 TTS 引擎。首次使用需授权麦克风并在系统中配置语音服务。语音识别能力、离线支持和语言质量取决于设备及系统服务。

## 当前不是一键上线产品
这份代码是完整功能方向的 MVP 起点。正式公开发布前仍需补充强身份认证、速率限制、HTTPS、备份、日志脱敏、隐私政策、崩溃监控和全面设备测试。
