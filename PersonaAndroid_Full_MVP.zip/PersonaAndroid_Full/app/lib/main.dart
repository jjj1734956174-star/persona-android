import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:uuid/uuid.dart';

const apiBase = String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000');
const uuid = Uuid();

void main() => runApp(const PersonaApp());

class PersonaApp extends StatelessWidget {
  const PersonaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: '专属人格',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF7063C8)),
      scaffoldBackgroundColor: const Color(0xFFF7F6FB),
      appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF7F6FB)),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18))),
    ),
    home: const HomePage(),
  );
}

class Character {
  String id, name, identity, personality, background, style, avatar;
  Character({required this.id, required this.name, this.identity='', this.personality='',
    this.background='', this.style='', this.avatar=''});
  Map<String,dynamic> toJson() => {'id':id,'name':name,'identity':identity,'personality':personality,
    'background':background,'style':style,'avatar':avatar};
  factory Character.fromJson(Map<String,dynamic> j) => Character(
    id:j['id']??uuid.v4(), name:j['name']??'未命名', identity:j['identity']??'',
    personality:j['personality']??'', background:j['background']??'', style:j['style']??'', avatar:j['avatar']??'');
}

class LocalStore {
  static const charsKey='persona_chars_v2', userKey='persona_user_v1', chatsKey='persona_chats_v1';
  static Future<String> userId() async {
    final p=await SharedPreferences.getInstance();
    var id=p.getString(userKey);
    if(id==null){id=uuid.v4(); await p.setString(userKey,id);}
    return id;
  }
  static Future<List<Character>> loadChars() async {
    final p=await SharedPreferences.getInstance(); final s=p.getString(charsKey);
    if(s==null)return [];
    try{return (jsonDecode(s) as List).map((e)=>Character.fromJson(Map<String,dynamic>.from(e))).toList();}catch(_){return [];}
  }
  static Future<void> saveChars(List<Character> list) async {
    final p=await SharedPreferences.getInstance();
    await p.setString(charsKey,jsonEncode(list.map((e)=>e.toJson()).toList()));
  }
  static Future<List<Map<String,String>>> loadChat(String id) async {
    final p=await SharedPreferences.getInstance(); final all=jsonDecode(p.getString(chatsKey)??'{}') as Map;
    final raw=(all[id] as List?)??[];
    return raw.map((e)=>Map<String,String>.from(e)).toList();
  }
  static Future<void> saveChat(String id,List<Map<String,String>> msgs) async {
    final p=await SharedPreferences.getInstance(); final all=jsonDecode(p.getString(chatsKey)??'{}') as Map;
    all[id]=msgs; await p.setString(chatsKey,jsonEncode(all));
  }
}

class Api {
  static Future<Map<String,dynamic>> chat(Character c,List<Map<String,String>> messages) async {
    final user=await LocalStore.userId();
    final res=await http.post(Uri.parse('$apiBase/chat'),
      headers:{'Content-Type':'application/json','X-User-ID':user},
      body:jsonEncode({'character':c.toJson(),'messages':messages}));
    if(res.statusCode>=400) throw Exception('服务端错误 ${res.statusCode}: ${res.body}');
    return jsonDecode(res.body) as Map<String,dynamic>;
  }
  static Future<List<dynamic>> memories(String characterId) async {
    final user=await LocalStore.userId();
    final res=await http.get(Uri.parse('$apiBase/memories?character_id=$characterId'),
      headers:{'X-User-ID':user});
    if(res.statusCode>=400) throw Exception('读取记忆失败');
    return (jsonDecode(res.body)['items'] as List);
  }
  static Future<void> addMemory(String characterId,String text) async {
    final user=await LocalStore.userId();
    final res=await http.post(Uri.parse('$apiBase/memories'),
      headers:{'Content-Type':'application/json','X-User-ID':user},
      body:jsonEncode({'character_id':characterId,'content':text}));
    if(res.statusCode>=400) throw Exception('保存记忆失败：${res.body}');
  }
  static Future<void> deleteMemory(int id) async {
    final user=await LocalStore.userId();
    final res=await http.delete(Uri.parse('$apiBase/memories/$id'),headers:{'X-User-ID':user});
    if(res.statusCode>=400) throw Exception('删除记忆失败');
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> {
  List<Character> items=[]; bool loading=true;
  @override void initState(){super.initState();load();}
  Future<void> load() async {final x=await LocalStore.loadChars();if(mounted)setState(() { items=x; loading=false; });}
  Future<void> edit([Character? c]) async {
    final v=await Navigator.push<Character>(context,MaterialPageRoute(builder:(_)=>CharacterEditor(old:c)));
    if(v==null)return;
    setState((){final i=items.indexWhere((e)=>e.id==v.id);if(i<0){items.insert(0,v);}else{items[i]=v;}});
    await LocalStore.saveChars(items);
  }
  Future<void> remove(Character c) async {
    setState(()=>items.removeWhere((e)=>e.id==c.id)); await LocalStore.saveChars(items);
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('专属人格',style:TextStyle(fontWeight:FontWeight.w800)),
      actions:[IconButton(onPressed:()=>edit(),icon:const Icon(Icons.add_circle_outline))]),
    floatingActionButton:FloatingActionButton.extended(onPressed:()=>edit(),icon:const Icon(Icons.add),label:const Text('创建角色')),
    body:loading?const Center(child:CircularProgressIndicator()):items.isEmpty
      ?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Icon(Icons.face_retouching_natural,size:76,color:Color(0xFF7063C8)),
        const SizedBox(height:12),const Text('创建你的第一个专属角色',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
        const SizedBox(height:8),const Text('设定人格、背景和表达方式'),
        const SizedBox(height:16),FilledButton(onPressed:()=>edit(),child:const Text('开始创建'))]))
      :ListView(padding:const EdgeInsets.all(16),children:[
        const Text('我的角色',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
        const SizedBox(height:6),Text('每个角色拥有独立的人格设定与聊天记录',style:TextStyle(color:Colors.grey.shade600)),
        const SizedBox(height:16),
        ...items.map((c)=>Card(child:ListTile(
          contentPadding:const EdgeInsets.all(14),
          leading:CircleAvatar(radius:25,child:Text(c.name.isEmpty?'人':c.name.substring(0,1))),
          title:Text(c.name,style:const TextStyle(fontWeight:FontWeight.bold)),
          subtitle:Text('${c.identity}\n${c.personality}',maxLines:2,overflow:TextOverflow.ellipsis),
          isThreeLine:true,
          onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>ChatPage(c:c))),
          trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')edit(c);if(v=='delete')remove(c);},
            itemBuilder:(_)=>const [PopupMenuItem(value:'edit',child:Text('编辑')),PopupMenuItem(value:'delete',child:Text('删除'))]),
        )))
      ]),
  );
}

class CharacterEditor extends StatefulWidget {
  final Character? old; const CharacterEditor({super.key,this.old});
  @override State<CharacterEditor> createState()=>_CharacterEditorState();
}
class _CharacterEditorState extends State<CharacterEditor>{
  final keyForm=GlobalKey<FormState>(); late TextEditingController n,i,p,b,s;
  @override void initState(){super.initState();final c=widget.old;n=TextEditingController(text:c?.name??'');i=TextEditingController(text:c?.identity??'');p=TextEditingController(text:c?.personality??'');b=TextEditingController(text:c?.background??'');s=TextEditingController(text:c?.style??'');}
  @override void dispose(){n.dispose();i.dispose();p.dispose();b.dispose();s.dispose();super.dispose();}
  Widget field(String label,TextEditingController ctl,String hint,{int lines=1,bool req=false})=>Padding(padding:const EdgeInsets.only(bottom:13),child:TextFormField(controller:ctl,maxLines:lines,validator:req?(v)=>(v==null||v.trim().isEmpty)?'请填写$label':null:null,decoration:InputDecoration(labelText:label,hintText:hint)));
  void save(){if(!keyForm.currentState!.validate())return;final c=widget.old;Navigator.pop(context,Character(id:c?.id??uuid.v4(),name:n.text.trim(),identity:i.text.trim(),personality:p.text.trim(),background:b.text.trim(),style:s.text.trim()));}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(widget.old==null?'创建角色':'编辑角色')),
    body:Form(key:keyForm,child:ListView(padding:const EdgeInsets.all(18),children:[
      const Text('定义一个独特的人格',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
      const SizedBox(height:18),field('角色名称',n,'例如：阿澈',req:true),
      field('身份',i,'例如：大学生、旅行顾问'),field('性格',p,'例如：温柔、幽默、理性',lines:3),
      field('背景故事',b,'角色经历、兴趣、世界观',lines:4),
      field('说话风格',s,'例如：自然口语化，简洁，不夸张',lines:3),
      FilledButton(onPressed:save,child:const Padding(padding:EdgeInsets.all(12),child:Text('保存角色')))
    ])));
}

class ChatPage extends StatefulWidget {final Character c;const ChatPage({super.key,required this.c});@override State<ChatPage> createState()=>_ChatPageState();}
class _ChatPageState extends State<ChatPage>{
  final input=TextEditingController();final scroll=ScrollController();final tts=FlutterTts();final speech=stt.SpeechToText();
  List<Map<String,String>> msgs=[];bool busy=false,listening=false;String? error;
  @override void initState(){super.initState();load();}
  Future<void> load() async {final x=await LocalStore.loadChat(widget.c.id);if(mounted)setState(()=>msgs=x);}
  Future<void> send() async {
    final text=input.text.trim();if(text.isEmpty||busy)return;
    setState(() { msgs.add({'role':'user','content':text}); busy=true; error=null; });input.clear();await LocalStore.saveChat(widget.c.id,msgs);
    try{
      final result=await Api.chat(widget.c,msgs);
      final reply=(result['reply']??'模型没有返回内容').toString();
      if(mounted)setState(()=>msgs.add({'role':'assistant','content':reply}));
      await LocalStore.saveChat(widget.c.id,msgs);
    }catch(e){if(mounted)setState(()=>error='连接失败：$e');}
    if(mounted)setState(()=>busy=false);
  }
  Future<void> voiceInput() async {
    final ok=await speech.initialize();
    if(!ok){setState(()=>error='语音识别不可用，请检查系统语音服务和麦克风权限');return;}
    setState(()=>listening=true);
    await speech.listen(onResult:(r){input.text=r.recognizedWords;input.selection=TextSelection.collapsed(offset:input.text.length);});
    await Future.delayed(const Duration(seconds:12));await speech.stop();if(mounted)setState(()=>listening=false);
  }
  Future<void> speak(String text) async {await tts.setLanguage('zh-CN');await tts.speak(text);}
  Future<void> memoryDialog() async {
    final ctl=TextEditingController();
    await showDialog(context:context,builder:(ctx)=>AlertDialog(title:const Text('添加角色记忆'),
      content:TextField(controller:ctl,maxLines:4,decoration:const InputDecoration(hintText:'只保存你明确希望角色记住的内容')),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('取消')),
        FilledButton(onPressed:()async{if(ctl.text.trim().isNotEmpty){try{await Api.addMemory(widget.c.id,ctl.text.trim());}catch(e){if(mounted)setState(()=>error='$e');}}if(ctx.mounted)Navigator.pop(ctx);},child:const Text('保存'))]));
  }
  Future<void> showMemories() async {
    try{
      final data=await Api.memories(widget.c.id);
      if(!mounted)return;
      showModalBottomSheet(context:context,isScrollControlled:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(16),child:Column(mainAxisSize:MainAxisSize.min,children:[
        const Text('角色长期记忆',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
        const SizedBox(height:12),
        if(data.isEmpty)const Text('还没有保存记忆'),
        ...data.map((m)=>ListTile(title:Text(m['content'].toString()),trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()async{await Api.deleteMemory(m['id'] as int);if(ctx.mounted)Navigator.pop(ctx);showMemories();}))),
        TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('关闭'))
      ]))));
    }catch(e){setState(()=>error='读取记忆失败：$e');}
  }
  @override void dispose(){input.dispose();scroll.dispose();tts.stop();speech.stop();super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      Text(widget.c.name,style:const TextStyle(fontWeight:FontWeight.bold)),
      Text(widget.c.personality.isEmpty?'专属角色':widget.c.personality,maxLines:1,style:const TextStyle(fontSize:11,color:Colors.grey))
    ]),actions:[
      PopupMenuButton<String>(onSelected:(v){if(v=='add')memoryDialog();if(v=='view')showMemories();},
        itemBuilder:(_)=>const [PopupMenuItem(value:'add',child:Text('添加长期记忆')),PopupMenuItem(value:'view',child:Text('管理长期记忆'))])
    ]),
    body:Column(children:[
      Expanded(child:msgs.isEmpty?Center(child:Text('开始和${widget.c.name}聊天吧')):ListView.builder(controller:scroll,padding:const EdgeInsets.all(14),itemCount:msgs.length,itemBuilder:(ctx,index){
        final m=msgs[index];final mine=m['role']=='user';final text=m['content']??'';
        return Align(alignment:mine?Alignment.centerRight:Alignment.centerLeft,child:Container(
          constraints:const BoxConstraints(maxWidth:320),margin:const EdgeInsets.only(bottom:10),padding:const EdgeInsets.all(13),
          decoration:BoxDecoration(color:mine?Theme.of(context).colorScheme.primaryContainer:Colors.white,borderRadius:BorderRadius.circular(16)),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
            Text(text),if(!mine)Align(alignment:Alignment.centerRight,child:IconButton(visualDensity:VisualDensity.compact,onPressed:()=>speak(text),icon:const Icon(Icons.volume_up,size:18)))
          ])));
      })),
      if(error!=null)Padding(padding:const EdgeInsets.all(6),child:Text(error!,style:const TextStyle(color:Colors.red,fontSize:12))),
      if(busy)const LinearProgressIndicator(),
      SafeArea(child:Padding(padding:const EdgeInsets.fromLTRB(10,6,10,10),child:Row(children:[
        IconButton(onPressed:voiceInput,icon:Icon(listening?Icons.mic:Icons.mic_none,color:listening?Colors.red:null)),
        Expanded(child:TextField(controller:input,minLines:1,maxLines:4,decoration:const InputDecoration(hintText:'发送消息…'))),
        const SizedBox(width:6),IconButton.filled(onPressed:busy?null:send,icon:const Icon(Icons.send))
      ])))
    ])
  );
}
