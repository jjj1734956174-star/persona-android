# 专属人格 Persona — Android 全栈 MVP

这是一个可继续构建的全栈 MVP 项目，目标是 Android 角色聊天 App。

## 当前包含
- Flutter Android 客户端源码
- 角色创建、编辑、删除
- 多角色聊天记录（本地保存）
- 可配置 OpenAI-compatible AI 服务商（通过后端代理）
- 后端角色与聊天 API
- SQLite 持久化
- 用户可查看、添加、删除长期记忆
- 语音输入（Android 系统/插件能力）和 TTS 播放
- Docker 后端部署文件与环境变量示例

## 重要：交付状态
这是源码项目，不是已编译 APK。当前环境没有 Android SDK / Flutter SDK，因此不能声称已完成 APK 编译或真机测试。第三方 AI 服务需要用户自行选择服务商并提供 API Key；密钥只放在后端 `.env`，不要放进 App。

## 目录
- `app/` Flutter 客户端
- `backend/` FastAPI 服务
- `docs/` 配置与发布说明

## 后端启动（电脑或支持 Docker 的云主机）
1. 复制 `backend/.env.example` 为 `backend/.env`
2. 填写 `AI_BASE_URL`、`AI_API_KEY`、`AI_MODEL`
3. 在 backend 目录运行：
   `pip install -r requirements.txt`
   `uvicorn app.main:app --host 0.0.0.0 --port 8000`
4. 打开 `http://服务器地址:8000/health`

也可使用 Docker Compose，见 `backend/docker-compose.yml`。

## Android 客户端配置
在 `app/` 目录执行 Flutter 构建时，通过 dart-define 指定后端地址：
`flutter build apk --release --dart-define=API_BASE_URL=https://你的后端域名`

本地 Android 模拟器通常使用 `http://10.0.2.2:8000`；真机需使用手机可访问的服务器 IP 或 HTTPS 域名。不要将 localhost 当作远程服务器地址。

## 安全与上线前必须完成
- 当前 `X-User-ID` 是 MVP 级用户分区标识，不等于强认证。正式上线前必须增加手机号/邮箱登录、JWT、限流、审计、HTTPS、备份和隐私政策。
- SQLite 适合个人测试；正式多人服务建议 PostgreSQL。
- 记忆默认由用户手动保存，不自动把所有聊天内容写入长期记忆。
- API Key 只保存在服务端环境变量。
- 不要向模型发送不必要的敏感个人信息。
- 语音识别与 TTS 可能调用设备系统或第三方服务，使用前应明确权限和隐私说明。
